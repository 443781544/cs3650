/* This file is lecture notes from CS 3650, Spring 2020 */
/* Author: Nat Tuck */


#ifndef TOKENIZE_H
#define TOKENIZE_H

#include "svec.h"

svec* tokenize(char* text);

#endif

